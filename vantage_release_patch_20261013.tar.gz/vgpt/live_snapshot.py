"""One authoritative view of the vehicle at a requested instant.

The head-unit and the question executor must not independently decide which
row means "now".  This module owns that decision and returns ``None`` when no
sample is close enough; a missing live value is never converted to zero.
"""
from . import qa_core as Q
import math


CONCEPT_TO_STATE = {
    "speed": "speed",
    "battery_soc": "soc",
    "battery_power": "power",
    "battery_temperature": "batt",
    "coolant_flow": "flow",
    "ambient_temperature": "amb",
    "hvac_power": "hvac",
    "motor_temperature": "motor",
    "drive_mode": "mode",
}


def snapshot(conn, ts):
    """Return the canonical live snapshot at ``ts``.

    ``available`` is false when neither a 1 Hz sample within five seconds nor
    a minute sample within sixty seconds exists.  Consumers may show an
    unknown state, but must not silently substitute zero or an old value.
    """
    requested = int(ts)
    state = Q.state_at(conn, requested)
    if state.get("gap") or "sample_ts" not in state:
        return {
            "available": False,
            "requested_ts": requested,
            "sample_ts": None,
            "age_s": None,
            "tier": None,
            "values": {},
            "prev": state.get("prev"),
            "next": state.get("next"),
        }
    sample_ts = int(state["sample_ts"])
    def valid(value):
        return None if isinstance(value, float) and not math.isfinite(value) else value

    values = {concept: valid(state.get(key)) for concept, key in CONCEPT_TO_STATE.items()}
    return {
        "available": True,
        "requested_ts": requested,
        "sample_ts": sample_ts,
        "age_s": max(0, requested - sample_ts),
        "tier": state.get("tier"),
        "values": values,
        "gps": state.get("gps"),
        "ext": state.get("ext"),
    }


def reading(conn, ts, concept):
    """Return one canonical live reading, or ``None`` if it is unavailable."""
    if concept not in CONCEPT_TO_STATE:
        return None
    snap = snapshot(conn, ts)
    value = snap["values"].get(concept) if snap["available"] else None
    return None if value is None else dict(snap, concept=concept, value=value)
