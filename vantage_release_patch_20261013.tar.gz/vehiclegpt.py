"""VehicleGPT launcher - the one command to remember.

  python vehiclegpt.py                 start the app and open it in your browser (same as 'run')
  python vehiclegpt.py run --no-browser --port 8800 --model none --db gen_courier.db
  python vehiclegpt.py doctor          check this computer and the install, say exactly what to fix
  python vehiclegpt.py smoke           start the app on a spare port, ask it a set of questions, report pass / fail (exit code 0 = healthy)
  python vehiclegpt.py feedback        summary of the thumbs-up / down people left (add --tsv out.tsv for a triage list)
  python vehiclegpt.py version
Everything runs on this computer; the app listens on 127.0.0.1 only and makes no network connections."""
import argparse, importlib.util, json, os, sys, threading, time, urllib.request, webbrowser

ROOT = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, ROOT)
from vgpt.version import VERSION
from vgpt import doctor


def _server_module():
    spec = importlib.util.spec_from_file_location("vgpt_ui_server", os.path.join(ROOT, "ui", "server.py")); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m


def _get(url, timeout=10): return json.loads(urllib.request.urlopen(url, timeout=timeout).read())


def _post(url, body, timeout=60): return json.loads(urllib.request.urlopen(urllib.request.Request(url, json.dumps(body).encode(), {"Content-Type": "application/json"}), timeout=timeout).read())


def start_server(port, model, db, camera="clip"):
    """-> (server, app, thread, port). Picks the next free port if the wanted one is taken."""
    m = _server_module(); port = doctor.find_free_port(port)
    a = m.build_parser().parse_args(["--port", str(port), "--model", model, "--camera", camera] + (["--db", db] if db else []))
    srv, app = m.make_server(a); t = threading.Thread(target=srv.serve_forever, daemon=True); t.start(); return srv, app, t, port


def cmd_run(a):
    checks = doctor.run_checks(ROOT, a.port, a.model)
    if doctor.summarize(checks)["fail"]:
        print(doctor.format_report(checks)); return 2
    for c in checks:
        if c["status"] == doctor.WARN and c["name"] == "Language model": print("note:", c["detail"])
    db = a.db if (not a.db or os.path.sep in a.db or "/" in a.db) else os.path.join("data", a.db)
    try: srv, app, t, port = start_server(a.port, a.model, db, a.camera)
    except (OSError, FileNotFoundError) as e: print("VehicleGPT could not start:", e, file=sys.stderr); return 2
    url = f"http://127.0.0.1:{port}"
    for _ in range(100):
        try: _get(url + "/api/health", 2); break
        except Exception: time.sleep(0.1)
    print(f"VehicleGPT {VERSION} is running at {url}   (Ctrl+C to stop; everything stays on this computer)")
    if not a.no_browser:
        try: webbrowser.open(url)
        except Exception: pass
    try:
        while True: time.sleep(1)
    except KeyboardInterrupt: print("\nstopping..."); srv.shutdown(); srv.server_close(); return 0


SMOKE = [("Brief me", None), ("how's my battery", None), ("is it safe to keep driving", None), ("when did I last charge", None), ("why is my battery power negative", None), ("how can I improve my range", None), ("hello", None), ("tell me a joke", "gate"),
         ("gaadi ka kya haal hai", None), ("what happened before the last warning", None), ("show me the last 5 diagnostic events", None), ("what is my range", None), ("how are my tyres", None), ("give me a summary of the week", None), ("what can I ask you", None)]


def cmd_smoke(a):
    import tempfile
    os.environ["VEHICLEGPT_HOME"] = tempfile.mkdtemp(prefix="vgpt_smoke_")                      # the self-test must not leave records in the person's real feedback file
    srv, app, t, port = start_server(8900, "none", a.db and (a.db if os.path.sep in a.db else os.path.join("data", a.db)), "clip"); url = f"http://127.0.0.1:{port}"; fails = []
    try:
        h = _get(url + "/api/health")
        if not h.get("ok"): fails.append("health")
        if "<title>VehicleGPT" not in urllib.request.urlopen(url + "/").read().decode("utf-8", "replace"): fails.append("front page")
        _get(url + "/api/state")
        for q, want in SMOKE:
            r = _post(url + "/api/ask", {"q": q})
            if not r.get("answer") or (want and r.get("path") != want) or "went wrong" in r.get("answer", ""): fails.append(q)
            if r.get("path") == "error": fails.append(q + " (error)")
        if not _post(url + "/api/feedback", {"rating": "up", "q": "smoke test", "brief": "ok", "route": "smoke"}).get("ok"): fails.append("feedback")
    except Exception as e: fails.append(f"{type(e).__name__}: {e}")
    finally: srv.shutdown(); srv.server_close()
    print("smoke test:", "PASSED" if not fails else "FAILED -> " + "; ".join(fails)); return 0 if not fails else 1


def cmd_feedback(a):
    from vgpt import feedback_report as F
    items = F.load(); print(F.format_report(items))
    if a.tsv: print(f"\nwrote {F.write_triage_tsv(items, a.tsv)} questions to {a.tsv}")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(prog="vehiclegpt", description="VehicleGPT launcher"); sub = ap.add_subparsers(dest="cmd")
    r = sub.add_parser("run", help="start the app (default)")
    for p in (r, ap):
        p.add_argument("--port", type=int, default=8765); p.add_argument("--model", default="0.5b", choices=["0.5b", "none"]); p.add_argument("--db", default=None, help="vehicle history, e.g. gen_courier.db"); p.add_argument("--camera", default="clip", choices=["clip", "webcam"]); p.add_argument("--no-browser", action="store_true")
    d = sub.add_parser("doctor", help="check this install"); d.add_argument("--json", action="store_true"); d.add_argument("--model", default="0.5b"); d.add_argument("--port", type=int, default=8765)
    s = sub.add_parser("smoke", help="self-test"); s.add_argument("--db", default=None)
    f = sub.add_parser("feedback", help="summarise user feedback"); f.add_argument("--tsv", default=None)
    sub.add_parser("version")
    a = ap.parse_args(argv)
    if a.cmd == "version": print(VERSION); return 0
    if a.cmd == "doctor":
        checks = doctor.run_checks(ROOT, a.port, a.model); print(json.dumps(checks, indent=1) if a.json else doctor.format_report(checks)); return 2 if doctor.summarize(checks)["fail"] else 0
    if a.cmd == "smoke": return cmd_smoke(a)
    if a.cmd == "feedback": return cmd_feedback(a)
    return cmd_run(a)


if __name__ == "__main__":
    sys.exit(main())
