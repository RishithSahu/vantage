"""VehicleGPT head-unit simulator: a car-style infotainment UI around the REAL assistant + camera pipeline, for hands-on testing.

  python ui/server.py                  http://127.0.0.1:8765   (recorded real dashcam clip, SLM = Qwen2.5-0.5B loaded on demand)
  python ui/server.py --model none     rules-only (no SLM)
  python ui/server.py --camera webcam  start on your webcam (cover it with your hand -> BLOCKED)

What is real here: the assistant (rules router, SLM, SQLite analytics), the camera analyser (vgpt/camera.py) and its ingest path (CameraAdapter -> Ingestor -> SQLite),
which every question reads. What is a stand-in for hardware: OpenCV decodes the video (a car's ISP/VPU would), and telemetry is REPLAYED from the simulated 28-day
history (it is not synchronised with the video). Runs on the host laptop; the 2 GB / 2-core budget is verified separately in the ARM VM (see README).
Binds 127.0.0.1 only; no network access is used."""
import argparse, atexit, importlib.util, json, os, queue, shutil, socket, sqlite3, sys, tempfile, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
for _v in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"): os.environ.setdefault(_v, "1")
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE); sys.path.insert(0, ROOT)
import cv2
import numpy as np
from vgpt import store, adapters, analytics as A, analytics_x as AX, paths, applog
from vgpt.version import VERSION
from vgpt.brain import Brain, LazySlm
from vgpt.product import make_brain, make_legacy_brain
from vgpt import interpret, toolspec as T
from ui import research as research_dashboard

CLIP = os.path.join(ROOT, "data", "ref", "camera_clip.hevc")
LEGACY_SCENARIOS = {   # sim epoch (UTC) inside the legacy 28-day history: trips / charge sessions that really exist in it
    "commute": ("Morning commute", 1790840676 - 30, "Thu 1 Oct 07:44 - 55 min city + motorway"),
    "highway": ("Long motorway run", 1790764200 + 600, "Wed 30 Sep 10:40 - 208 km"),
    "charge": ("DC fast charging", 1790773020 - 60, "Wed 30 Sep 12:56 - 118 kW session"),
    "evening": ("Evening drive", 1790874174 + 60, "Thu 1 Oct 17:03 - 52 min"),
}
FAULTS = ("none", "cover", "mud", "blur", "glare", "dark")
MAX_BODY = 64 * 1024                                                    # no request this app makes is bigger than a few hundred bytes
VIDEO_EXT = (".mp4", ".avi", ".mov", ".mkv", ".hevc", ".webm", ".m4v", ".h264")
STARTED = time.time()
LOG = applog.get()


def make_scenarios(c, tz):
    """Interesting moments of the loaded vehicle history: key -> (name, sim epoch to start at, description). Generated vehicles get them from their own trips and events."""
    lt = lambda ts: time.strftime("%a %d %b %H:%M", time.gmtime(ts + tz))
    try:
        rows = c.execute("SELECT t.start, t.end, t.km, COALESCE(x.rain_share,0), COALESCE(x.harsh_brake,0)+COALESCE(x.harsh_accel,0)+COALESCE(x.harsh_corner,0), COALESCE(x.adas_share,0) FROM trips t JOIN trip_ext x ON x.start=t.start ORDER BY t.start").fetchall()
    except sqlite3.Error: rows = []
    if not rows: return dict(LEGACY_SCENARIOS)
    hour = lambda ts: ((ts + tz) % 86400) / 3600.0; wd = lambda ts: ((ts + tz) // 86400 + 3) % 7 < 5; sc = {}
    am = [r for r in rows if wd(r[0]) and 6 <= hour(r[0]) < 10.5 and r[2] > 3]; pm = [r for r in rows if wd(r[0]) and 16 <= hour(r[0]) < 20 and r[2] > 3]
    if am: r = am[-1]; sc["morning"] = ("Morning commute", r[0] - 40, f"{lt(r[0])} - {r[2]:.0f} km, {(r[1] - r[0]) // 60} min")
    if pm: r = pm[-1]; sc["evening"] = ("Evening drive", r[0] - 40, f"{lt(r[0])} - {r[2]:.0f} km, {(r[1] - r[0]) // 60} min")
    r = max(rows, key=lambda r: r[2]); sc["long"] = ("Longest trip", r[0] - 40, f"{lt(r[0])} - {r[2]:.0f} km")
    rr = max(rows, key=lambda r: r[3])
    if rr[3] > 0.15: sc["rain"] = ("Driving in rain", rr[0] - 40, f"{lt(rr[0])} - rain for {rr[3] * 100:.0f}% of the trip")
    hh = max(rows, key=lambda r: r[4])
    if hh[4] >= 3: sc["harsh"] = ("Spirited drive", hh[0] - 40, f"{lt(hh[0])} - {hh[4]} hard braking/acceleration/cornering events")
    ad = max(rows, key=lambda r: r[5])
    if ad[5] > 20: sc["adas"] = ("Lane assist on the motorway", ad[0] - 40, f"{lt(ad[0])} - lane assist engaged {ad[5]:.0f}% of the trip")
    try:
        ch = c.execute("SELECT start, kind, kw FROM charges ORDER BY (kind='DC') DESC, start LIMIT 1").fetchone()
        if ch: sc["charge"] = ("DC fast charging" if ch[1] == "DC" else "Home charging", ch[0] - 60, f"{lt(ch[0])} - {ch[2]:.0f} kW {ch[1]} session")
        tp = c.execute("SELECT ts, detail FROM events WHERE type='TPMS_LOW' ORDER BY ts LIMIT 1").fetchone()
        if tp: sc["tyre"] = ("Tyre warning appears", tp[0] - 300, f"{lt(tp[0])} - {tp[1][:48]}")
        ot = c.execute("SELECT ts, detail FROM events WHERE type='WARN_BATT_OVERTEMP' ORDER BY ts DESC LIMIT 1").fetchone()
        if ot: sc["overheat"] = ("Battery overheating warning", ot[0] - 420, f"{lt(ot[0])} - {ot[1][:48]} (the assistant raises it by itself)")
        cm = c.execute("SELECT ts, detail FROM events WHERE type='CAMERA_BLOCKED' ORDER BY ts LIMIT 1").fetchone()
        if cm: sc["camera"] = ("Camera blocked", cm[0] - 300, f"{lt(cm[0])} - {cm[1][:48]}")
    except sqlite3.Error: pass
    return sc


def rss_mb():
    try:
        import ctypes, ctypes.wintypes as wt
        class PMC(ctypes.Structure):
            _fields_ = [("cb", wt.DWORD), ("PageFaultCount", wt.DWORD)] + [(n, ctypes.c_size_t) for n in ("PeakWorkingSetSize", "WorkingSetSize", "QPP", "QP", "QPNP", "QNP", "PagefileUsage", "PeakPagefileUsage")]
        k = ctypes.windll.kernel32; k.GetCurrentProcess.restype = ctypes.c_void_p
        ps = ctypes.windll.psapi; ps.GetProcessMemoryInfo.argtypes = [ctypes.c_void_p, ctypes.POINTER(PMC), wt.DWORD]
        p = PMC(); p.cb = ctypes.sizeof(p); ps.GetProcessMemoryInfo(k.GetCurrentProcess(), ctypes.byref(p), p.cb)
        return round(p.WorkingSetSize / 2 ** 20)
    except Exception:
        try: return round(int([l for l in open("/proc/self/status") if l.startswith("VmRSS")][0].split()[1]) / 1024)
        except Exception: return 0


class Clock:
    """Simulated vehicle clock. speed: sim seconds per real second."""
    def __init__(self, t, speed=1.0): self.t0, self.m0, self.speed, self.scenario = t, time.monotonic(), speed, "commute"
    def now(self): return self.t0 + (time.monotonic() - self.m0) * self.speed
    def set(self, t=None, speed=None, scenario=None):
        n = self.now(); self.t0, self.m0 = (n if t is None else t), time.monotonic()
        if speed is not None: self.speed = speed
        if scenario is not None: self.scenario = scenario


def apply_fault(fr, kind, t):
    """Optical faults applied to the colour frame, exactly where the lens would: the user SEES the fault and the analyser has to find it."""
    h, w = fr.shape[:2]
    if kind == "cover": return np.clip(8 + np.random.randn(h, w, 3) * 0.8, 0, 255).astype(np.uint8)
    if kind == "mud":
        yy, xx = np.mgrid[0:h, 0:w]; d = ((xx - 0.40 * w) / (0.55 * w)) ** 2 + ((yy - 0.42 * h) / (0.55 * h)) ** 2; m = np.clip((1.0 - d) * 4, 0, 1)[..., None]
        mud = np.array([38, 52, 66], np.float32) + 5 * np.sin(xx / 60.0)[..., None]
        return (fr * (1 - m) + mud * m).astype(np.uint8)
    if kind == "blur": return cv2.GaussianBlur(fr, (0, 0), 7)
    if kind == "glare":
        yy, xx = np.mgrid[0:h, 0:w]; d = np.sqrt(((xx - 0.7 * w) / (0.75 * w)) ** 2 + ((yy - 0.25 * h) / (0.9 * h)) ** 2)
        return np.clip(fr.astype(np.float32) + 330 * np.clip(1.0 - d, 0, 1)[..., None] ** 0.8, 0, 255).astype(np.uint8)
    if kind == "dark": return (fr.astype(np.float32) * 0.15).astype(np.uint8)
    return fr


class CameraRig(threading.Thread):
    """Capture -> (fault injection) -> display JPEG + 5 fps luma analysis -> CameraAdapter/Ingestor (the only writer to the live DB)."""
    def __init__(self, db, clock, source):
        super().__init__(daemon=True); self.db, self.clock = db, clock
        self.want = source; self.fault = "none"; self.cmd = None; self.err = ""; self.ms = 0.0; self.fps = 0.0; self.feats = {}; self.src_label = ""
        self.jpeg = None; self.cond = threading.Condition(); self.seq = 0; self.wipe_from = 0

    def _open(self, key):
        kind, arg = key
        if kind == "webcam": cap = cv2.VideoCapture(int(arg), cv2.CAP_DSHOW)
        else: cap = cv2.VideoCapture(CLIP if kind == "clip" else arg)
        if not cap.isOpened(): self.err = {"webcam": f"cannot open webcam {arg} (in use by another app, or blocked by Windows camera privacy settings)", "clip": "recorded clip missing (data/ref/camera_clip.hevc)"}.get(kind, f"cannot open {arg}"); return None
        self.err = ""; self.src_label = {"clip": "Recorded dashcam clip (comma2k19)", "webcam": f"Webcam {arg}"}.get(kind, os.path.basename(str(arg))); return cap

    def _fresh(self):
        conn = store.open_rw(self.db)
        w = int(self.wipe_from)                                                 # keep the camera history BEFORE the scenario start; what happens next is live
        for sql in ("DELETE FROM events WHERE type IN ('CAMERA_BLOCKED','CAMERA_DEGRADED','CAMERA_RESTORED') AND ts>=?", "DELETE FROM event_thumb WHERE ts>=?", "DELETE FROM cam_1m WHERE ts>=?", "DELETE FROM event_ctx WHERE type LIKE 'CAMERA%' AND ts>=?"): conn.execute(sql, (w,))
        return conn, store.Ingestor(conn, adapters.Router())

    def run(self):
        conn, ing = self._fresh(); cap = None; key = None; last_an = last_snap = last_fps = 0.0; nfr = 0; nxt = time.monotonic()
        while True:
            if self.cmd == "reset": ing.close(); conn.close(); conn, ing = self._fresh(); self.cmd = None; self.feats = {}
            if self.want != key:
                if cap is not None: cap.release()
                key = self.want; cap = self._open(key); ing.router.cam.monitors.clear(); self.feats = {}
            if cap is None: time.sleep(1.0); cap = self._open(key); continue
            ok, fr = cap.read()
            if not ok:
                if key[0] == "webcam": self.err = "webcam stopped delivering frames"; time.sleep(0.3); continue
                cap.release(); cap = self._open(key)                           # loop: re-open (seeking is unreliable for raw HEVC)
                ok, fr = cap.read() if cap is not None else (False, None)
                if not ok: self.err = self.err or "cannot read the video"; time.sleep(0.5); continue
            if key[0] != "webcam":                                              # pace recorded video at its own frame rate
                fps = cap.get(cv2.CAP_PROP_FPS) or 25.0; nxt += 1.0 / fps; d = nxt - time.monotonic()
                if d > 0: time.sleep(d)
                else: nxt = time.monotonic()
            self.err = ""
            fr = cv2.resize(fr, (640, 480), interpolation=cv2.INTER_AREA); mono = time.monotonic(); fr = apply_fault(fr, self.fault, mono)
            nfr += 1
            if mono - last_fps >= 1.0: self.fps = nfr / (mono - last_fps); nfr = 0; last_fps = mono
            if mono - last_an >= 0.2:                                           # 5 fps analysis, as in the car
                last_an = mono; g = cv2.cvtColor(fr, cv2.COLOR_BGR2GRAY); t0 = time.perf_counter()
                ing.feed(self.clock.now(), "cam", {"cam": "front", "t": mono, "w": 640, "h": 480, "y": g.tobytes()})
                self.ms = 0.9 * self.ms + 0.1 * (time.perf_counter() - t0) * 1000 if self.ms else (time.perf_counter() - t0) * 1000
                mon = ing.router.cam.monitors.get("front"); self.feats = dict(mon.last) if mon else {}
            if ing.pending_events or mono - last_snap >= 1.0: last_snap = mono; ing.snapshot()      # events become visible to the assistant immediately
            ok, jb = cv2.imencode(".jpg", fr, [cv2.IMWRITE_JPEG_QUALITY, 72])
            with self.cond: self.jpeg = jb.tobytes(); self.seq += 1; self.cond.notify_all()


class BrainWorker(threading.Thread):
    """Owns the Brain (SQLite handles are thread-bound) and answers one question at a time, as the single assistant process in the car would."""
    def __init__(self, db, slm, clock, planner_factory=None, brain_factory=make_brain):
        super().__init__(daemon=True); self.db, self.slm, self.clock, self.planner_factory, self.brain_factory = db, slm, clock, planner_factory, brain_factory; self.q = queue.Queue(); self.busy = False; self.ready = threading.Event(); self.units = {"p": "kpa", "d": "km", "t": "c"}

    def run(self):
        brain = self.brain_factory(self.db, slm=self.slm)
        self.load_error = None
        if self.planner_factory is not None:
            try: brain._P = self.planner_factory(brain.c)                                                  # the language model is loaded once; tests hand in a deterministic stand-in
            except Exception as e: self.load_error = f"{type(e).__name__}: {e}"; LOG.exception("could not load the language model"); brain._P = None
        self.ready.set()
        while True:
            text, persona, box, ev = self.q.get(); self.busy = True
            if text == "__units__":
                brain.units.update({k: v for k, v in persona.items() if k in ("p", "d", "t")}); self.units = dict(brain.units); box.append({"ok": True}); self.busy = False; ev.set(); continue
            if text in ("__propose__", "__confirm__") and self.load_error:
                box.append({"ok": False, "fn": None, "fields": [], "error": "the language model could not be loaded: " + self.load_error, "answer": "The language model could not be loaded, so I cannot interpret questions.", "path": "error", "intent": "NONE", "ms": {"total": 0}, "params": {}}); self.busy = False; ev.set(); continue
            if text == "__propose__":
                try: brain.now = int(self.clock.now()); box.append(interpret.propose(brain, persona["q"], bool(persona.get("follow_up"))))
                except Exception as e: box.append({"ok": False, "fn": None, "fields": [], "error": f"{type(e).__name__}"})
                self.busy = False; ev.set(); continue
            if text == "__confirm__":
                try:
                    brain.now = int(self.clock.now()); brain.persona = persona.get("persona", "driver"); r = brain.ask_confirmed(persona["q"], persona["fn"], persona["args"]); f_ = r.pop("facts", None); r["route"] = f_.get("route") if isinstance(f_, dict) else None; box.append(r)
                except Exception as e: box.append({"answer": f"Sorry, something went wrong ({type(e).__name__}).", "intent": "NONE", "path": "error", "ms": {"total": 0}, "params": {}})
                self.busy = False; ev.set(); continue
            if text == "__catalogue__":
                try:
                    from vgpt import capreg, signal_registry as R
                    box.append(interpret.catalogue(brain._P.reg if brain._P is not None else capreg.CapabilityRegistry(R.Profile(brain.c))))        # the catalogue needs the registry, not the language model
                except Exception as e: box.append({"ok": False, "error": f"{type(e).__name__}"})
                self.busy = False; ev.set(); continue
            if text == "__reload__":
                try:
                    u = dict(brain.units); P = getattr(brain, "_P", None); brain.c.close(); brain = self.brain_factory(persona, slm=self.slm); brain.units = u
                    if P is not None: P.reload_schema(brain.c); brain._P = P                                 # the loaded model is kept; everything that depends on the vehicle's schema is regenerated
                    box.append({"ok": True})
                except Exception as e: box.append({"ok": False, "error": str(e)})
                self.busy = False; ev.set(); continue
            try:
                brain.now = int(self.clock.now()); brain.persona = persona; r = brain.ask(text); f_ = r.pop("facts", None); r["route"] = f_.get("route") if isinstance(f_, dict) else None; self.units = dict(brain.units); box.append(r)
            except Exception as e: box.append({"answer": f"Sorry, something went wrong ({type(e).__name__}).", "intent": "NONE", "path": "error", "ms": {"total": 0}, "params": {}})
            self.busy = False; ev.set()

    def set_units(self, u):
        box, ev = [], threading.Event(); self.q.put(("__units__", u, box, ev)); ev.wait(10); return box[0] if box else {"ok": False}

    def reload(self, path):
        box, ev = [], threading.Event(); self.q.put(("__reload__", path, box, ev)); ev.wait(60); return box[0] if box else {"ok": False}

    def call(self, cmd, payload, wait=120):
        box, ev = [], threading.Event(); self.q.put((cmd, payload, box, ev)); ev.wait(wait); return box[0] if box else {"ok": False, "error": "timed out"}

    def ask(self, text, persona):
        box, ev = [], threading.Event(); self.q.put((text, persona, box, ev)); ev.wait(120); return box[0] if box else {"answer": "Timed out.", "intent": "NONE", "path": "error", "ms": {"total": 0}, "params": {}}


class App:
    def __init__(self, a, planner_factory=None):
        self.preset = getattr(a, "planner", "fast"); self.threads = getattr(a, "threads", 2)
        # A planner_factory is a deterministic test seam.  The shipped server has
        # exactly one neural-model option: the lazy Qwen2.5 0.5B fallback below.
        # Larger research planners are deliberately unreachable from this app.
        explicit_planner = planner_factory is not None
        if not explicit_planner and self.preset != "fast":
            raise ValueError("the UI supports only the 0.5B fast configuration")
        model_name = getattr(a, "model", "0.5b")
        if not explicit_planner and model_name not in ("0.5b", "none"):
            raise ValueError("the UI permits only Qwen2.5 0.5B (or 'none' for diagnostics)")
        self.model_requested = model_name
        self.model_unavailable_reason = None
        brain_factory = make_brain if explicit_planner else make_legacy_brain
        if not explicit_planner:
            # Do not load the separately trained TF-IDF question classifier.
            # Regex/typed parsing and nearest-example lookup remain deterministic;
            # Qwen2.5 0.5B is therefore the only learned model in the UI process.
            os.environ["VGPT_NO_QA_CLF"] = "1"
        self.fb_lock = threading.Lock(); self.tmp = tempfile.mkdtemp(prefix="vehiclegpt_"); self.port = getattr(a, "port", 8765); atexit.register(shutil.rmtree, self.tmp, True)       # this run's private working copy of the history
        self.root = ROOT; self.seq = 0; self.gen = 0; self.tl = threading.local(); self.tele_cache = (0, None); self.tyre_cache = (0, None); self.pos_cache = (0, None); self.db = None; self.live_override = getattr(a, "live", None)
        slm = None
        if not explicit_planner and model_name != "none":
            p = os.path.join(ROOT, "models", "qwen2.5-0.5b-instruct-q4_k_m.gguf")
            if not os.path.exists(p):
                self.model_unavailable_reason = "model file is missing"
                LOG.warning("language model file missing (%s): running on the typed parser only", p)
            elif importlib.util.find_spec("llama_cpp") is None:
                self.model_unavailable_reason = "llama-cpp-python is not installed"
                LOG.warning("llama-cpp-python is not installed: running on the typed parser only")
            else:
                adapter = os.path.join(ROOT, "models", "semantic-lora-qwen25-05b-v2.gguf") if os.environ.get("VGPT_SEMANTIC_FRONTDOOR") == "1" else None
                state_path = os.path.join(paths.home(), "qwen2.5-0.5b-prefix-v1.pkl")
                slm = LazySlm(p, idle_s=120, threads=min(2, max(1, self.threads)), mmap=True, fmt="words", n_batch=128, state_path=state_path,
                              lora_path=adapter if adapter and os.path.exists(adapter) else None)
        elif not explicit_planner:
            self.model_unavailable_reason = "disabled by configuration"
        self.slm = slm; self.clock = Clock(0); self._copy(a.db)
        self.rig = CameraRig(self.db, self.clock, ("webcam", a.webcam_index) if a.camera == "webcam" else ("clip", None)); self.rig.wipe_from = self.clock.now() - 1800; self.rig.start()
        self.brain = BrainWorker(self.db, slm, self.clock, planner_factory, brain_factory); self.brain.start(); self.brain.ready.wait(20)

    # ---- datasets
    def datasets(self):
        out = []
        for f in sorted(os.listdir(os.path.join(ROOT, "data"))):
            if f == "vehicle.db" or (f.startswith("gen_") and f.endswith(".db")):
                try:
                    c = sqlite3.connect(f"file:{os.path.join(ROOT, 'data', f)}?mode=ro", uri=True); m = dict(c.execute("SELECT k, v FROM meta").fetchall()); c.close()
                    lab = f"{m.get('veh.model', '60 kWh EV')} - {m.get('env.city', 'simulated')} - {m.get('gen.driver', 'scripted story').replace('_', ' ')}"
                except sqlite3.Error: lab = f
                out.append({"name": f, "label": lab})
        return out

    def _copy(self, name):
        src = name if os.path.isabs(name) else os.path.join(ROOT, name if os.path.sep in name or "/" in name else os.path.join("data", name))
        if not os.path.exists(src): raise FileNotFoundError(src)
        self.seq += 1; old = self.db; self.db = self.live_override if (self.live_override and self.seq == 1) else os.path.join(self.tmp, f"live_{self.seq}.db")
        for ext in ("", "-wal", "-shm"):
            try: os.remove(self.db + ext)
            except OSError: pass
        s = sqlite3.connect(src); d = sqlite3.connect(self.db); s.backup(d); d.close(); s.close()
        c = sqlite3.connect(self.db); m = dict(c.execute("SELECT k, v FROM meta").fetchall())
        self.meta = m; self.tz = int(float(m.get("env.tz_h", 0)) * 3600); self.scen = make_scenarios(c, self.tz); c.close()
        first = "morning" if "morning" in self.scen else next(iter(self.scen)); self.clock.set(t=self.scen[first][1], scenario=first); self.dataset = os.path.basename(src); self.gen += 1; self.tele_cache = (0, None); self.tyre_cache = (0, None); self.pos_cache = (0, None)
        return old

    def load(self, name):
        old = self._copy(name); self.rig.db = self.db; self.rig.wipe_from = self.clock.now() - 1800; self.rig.cmd = "reset"; r = self.brain.reload(self.db)
        for _ in range(40):                                                    # wait until the rig has re-opened the new file, then drop the old copy
            if self.rig.cmd is None: break
            time.sleep(0.05)
        if old and old != self.db:
            for ext in ("", "-wal", "-shm"):
                try: os.remove(old + ext)
                except OSError: pass
        return r

    def ro(self):
        c = getattr(self.tl, "c", None)
        if c is None or getattr(self.tl, "gen", -1) != self.gen:
            if c is not None:
                try: c.close()
                except sqlite3.Error: pass
            c = self.tl.c = store.open_ro(self.db); self.tl.gen = self.gen
        return c

    def telemetry(self, t):
        from vgpt import live_snapshot as LIVE
        c = self.ro(); A.set_tz(self.tz); snap = LIVE.snapshot(c, int(t)); v = snap["values"]
        mode = v.get("drive_mode")
        out = {"ok": snap["available"], "live": snap["available"], "sample_ts": snap["sample_ts"], "age_s": snap["age_s"], "tier": snap["tier"],
               "speed": v.get("speed"), "soc": v.get("battery_soc"), "power_kw": v.get("battery_power"), "batt_c": v.get("battery_temperature"),
               "amb_c": v.get("ambient_temperature"), "hvac_w": v.get("hvac_power"), "motor_c": v.get("motor_temperature"), "mode": mode,
               "gear": None if mode is None else ("P" if mode in (0, 3) else "D"), "flow": v.get("coolant_flow")}
        if time.monotonic() - self.tele_cache[0] > 5: self.tele_cache = (time.monotonic(), A.est_range(c, int(t)))
        er = self.tele_cache[1] or {}
        if er.get("ok"): out.update(range_km=er["range_km"], wh_km=er["wh_km"])
        try:
            x = c.execute("SELECT ts, rain, lux, v12, adas FROM ext_1m WHERE ts<=? AND ts>? ORDER BY ts DESC LIMIT 1", (int(t), int(t) - 180)).fetchone()
            out.update(rain=x[1] if x else 0, lux=x[2] if x else None, sensors=bool(x), adas=x[4] if x else 0)
            if time.monotonic() - self.tyre_cache[0] > 4: self.tyre_cache = (time.monotonic(), AX.tyres(c, int(t), "14"))
            ty = self.tyre_cache[1]
            if ty and ty.get("ok"): out.update(tyres=[{"n": w["name"], "kpa": w["kpa"], "st": w["status"]} for w in ty["wheels"]], tpms=ty["active_warnings"])
            if time.monotonic() - self.pos_cache[0] > 0.8:
                pr = AX.places(c, int(t), "y", "here_only"); self.pos_cache = (time.monotonic(), pr["here"] if pr.get("ok") and pr.get("here") else None)
            if self.pos_cache[1]: out["pos"] = self.pos_cache[1]
        except sqlite3.Error: pass
        return out

    def events(self, t, n=14):
        c = self.ro(); A.set_tz(self.tz); rows = c.execute("SELECT e.ts, e.type, e.sev, e.detail, (SELECT 1 FROM event_thumb th WHERE th.ts=e.ts AND th.type=e.type) FROM events e WHERE e.ts<=? AND e.type IN "
                                        "('CAMERA_BLOCKED','CAMERA_DEGRADED','CAMERA_RESTORED','ADAS_DISENGAGE','WARN_BATT_OVERTEMP','DTC_SET','CHARGE_START','TPMS_LOW','TYRE_INFLATED','LOW_12V','SERVICE_DUE','SW_UPDATE') ORDER BY e.ts DESC LIMIT ?", (int(t), n)).fetchall()
        return [{"ts": r[0], "type": r[1], "sev": r[2], "detail": r[3], "thumb": bool(r[4])} for r in rows]

    def state(self):
        t = self.clock.now(); f = self.rig.feats or {}
        cam = {"state": f.get("state", "CALIBRATING"), "reason": f.get("reason", ""), "cond": f.get("cond", ""), "blocked_frac": f.get("blocked_frac", 0), "sharp_ratio": f.get("sharp_ratio", 1), "luma": f.get("luma", 0),
               "lane_conf": f.get("lane_conf", 0), "low_light": f.get("low_light", False), "lost": f.get("lost"), "fps": round(self.rig.fps, 1), "ms": round(self.rig.ms, 1), "source": self.rig.src_label,
               "fault": self.rig.fault, "error": self.rig.err}
        slm = self.slm; db_mb = round(sum(os.path.getsize(self.db + e) for e in ("", "-wal") if os.path.exists(self.db + e)) / 2 ** 20, 1); m = self.meta
        info = {"dataset": self.dataset, "model": m.get("veh.model", "Family EV 60 kWh (scripted story)"), "city": m.get("env.city", "simulated"), "driver": m.get("gen.driver", "scripted").replace("_", " "), "stories": [x for x in m.get("gen.stories", "").split(",") if x],
                "weather": m.get("gen.weather", "synthetic"), "seed": m.get("gen.seed"), "tz_h": self.tz / 3600.0}
        return {"sim_t": t, "tz": self.tz, "clock": {"speed": self.clock.speed, "scenario": self.clock.scenario}, "tele": self.telemetry(t), "cam": cam, "events": self.events(t), "info": info, "units": self.brain.units,
                "sys": {"rss_mb": rss_mb(), "budget_mb": 2048, "model": None if slm is None else {"loaded": slm.loaded, "loads": slm.loads, "load_s": round(slm.load_s + slm.warm_s, 1)}, "db_mb": db_mb, "busy": self.brain.busy},
                "scenarios": {k: {"name": v[0], "desc": v[2]} for k, v in self.scen.items()}}

    def track(self, seconds):
        A.set_tz(self.tz); return AX.track(self.ro(), int(self.clock.now()), max(60, min(int(seconds), 14400)))

    def health(self):
        """What a status page / the launcher's doctor needs: is the assistant alive and in which mode."""
        slm = self.slm
        if slm is not None:
            mode = "typed parser + Qwen2.5 0.5B fallback (only neural language model)"
        elif self.model_requested == "none":
            mode = "typed parser only (neural fallback disabled)"
        else:
            mode = "typed parser only (Qwen2.5 0.5B fallback unavailable)"
        return {"ok": True, "version": VERSION, "uptime_s": round(time.time() - STARTED), "dataset": getattr(self, "dataset", None), "mode": mode, "planner_preset": getattr(self, "preset", None), "classifier": False,
                "model": {"requested": self.model_requested, "name": "Qwen2.5-0.5B-Instruct" if self.model_requested != "none" else None,
                          "available": slm is not None, "loaded": bool(slm and slm.loaded), "reason": self.model_unavailable_reason},
                "camera": {"source": self.rig.src_label, "error": self.rig.err or None}, "busy": self.brain.busy, "queued": self.brain.q.qsize()}

    def feedback(self, j):
        """A thumbs up / down (and an optional note) on one answer, saved on this computer only - a person's own consent: nothing is stored unless they press the button."""
        rating = j.get("rating")
        if rating not in ("up", "down"): return {"ok": False, "error": "rating must be up or down"}
        cut = lambda k, n: str(j.get(k) or "")[:n]
        rec = {"t": int(time.time()), "version": VERSION, "dataset": getattr(self, "dataset", None), "rating": rating, "q": cut("q", 300), "brief": cut("brief", 600), "route": cut("route", 60), "path": cut("path", 20), "note": cut("note", 500)}
        f = paths.feedback_file()
        try:
            if os.path.exists(f) and os.path.getsize(f) > 5_000_000: os.replace(f, f + ".1")            # keep at most ~10 MB of feedback
            with self.fb_lock, open(f, "a", encoding="utf-8") as fh: fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
        except OSError:
            LOG.exception("could not save feedback"); return {"ok": False, "error": "could not save feedback on this computer"}
        LOG.info("feedback %s on route=%s", rating, rec["route"]); return {"ok": True}

    def log_interaction(self, rec):
        """One line per interaction in the interpretation-review prototype, on this computer only (it is the record of the user study: unassisted correctness, edits, time)."""
        f = os.path.join(paths.home(), "interaction_log.jsonl"); rec = dict(rec, t=int(time.time()), version=VERSION, dataset=getattr(self, "dataset", None))
        try:
            with self.fb_lock, open(f, "a", encoding="utf-8") as fh: fh.write(json.dumps(rec, ensure_ascii=False) + chr(10))
        except OSError: LOG.exception("could not write the interaction log")

    def interpret(self, j):
        q = str(j.get("q", ""))[:300].strip()
        if not q: return {"ok": False, "error": "empty question"}
        t0 = time.time(); p = self.brain.call("__propose__", {"q": q, "follow_up": bool(j.get("follow_up"))}); p["propose_ms"] = round((time.time() - t0) * 1000)
        self.log_interaction({"event": "proposed", "participant": str(j.get("participant", ""))[:40], "task": str(j.get("task", ""))[:40], "goal": str(j.get("goal", ""))[:300], "follow_up": bool(j.get("follow_up")), "original_text": q, "proposal": {"fn": p.get("fn"), "args": p.get("args"), "raw": p.get("raw"), "timing": p.get("timing")}, "propose_ms": p["propose_ms"]}); return p

    def execute(self, j):
        """Run the interpretation the person confirmed. `proposal` is what the model proposed (kept for the record), `final` what is confirmed."""
        q = str(j.get("q", ""))[:300].strip(); fin = j.get("final") or {}; prop = j.get("proposal") or {}; fn = fin.get("fn")
        if not q or fn not in T.FUNCS or fn == "say": return {"ok": False, "error": "no operation chosen"}
        args = interpret.clean_args(fn, fin.get("args") or {})
        for k in ("k",):
            if k in args:
                try: args[k] = int(args[k])
                except (TypeError, ValueError): return {"ok": False, "error": f"{k} must be a whole number"}
        r = self.brain.call("__confirm__", {"q": q, "fn": fn, "args": args, "persona": "engineer" if j.get("persona") == "engineer" else "driver"})
        edits = interpret.diff(prop.get("args"), fn, args, prop.get("fn")); rebuilt = (not prop.get("fn")) or any(e["field"] == "operation" for e in edits) or len(edits) >= 3                # the person rebuilt the query rather than corrected it: reported separately, never counted as the model's success
        rec = {"event": "executed", "participant": str(j.get("participant", ""))[:40], "task": str(j.get("task", ""))[:40], "original_text": q, "proposal": {"fn": prop.get("fn"), "args": prop.get("args"), "raw": prop.get("raw"), "timing": prop.get("timing")}, "final": {"fn": fn, "args": args}, "edits": edits, "n_edits": len(edits), "rebuilt": rebuilt, "goal": str(j.get("goal", ""))[:300],
               "client": j.get("client") or {}, "outcome": (r.get("facts") or {}).get("outcome") if isinstance(r.get("facts"), dict) else r.get("outcome"), "answer": str(r.get("answer", ""))[:600], "path": r.get("path")}
        self.log_interaction(rec); r["edits"] = edits; return r

    def judge(self, j):
        """The person's own verdict on the answer ('this is what I asked for' / not), logged next to the interaction."""
        v = j.get("verdict")
        if v not in ("yes", "no"): return {"ok": False, "error": "verdict must be yes or no"}
        sat = j.get("satisfaction"); sat = int(sat) if isinstance(sat, (int, float)) and 1 <= int(sat) <= 5 else None
        self.log_interaction({"event": "judged", "participant": str(j.get("participant", ""))[:40], "task": str(j.get("task", ""))[:40], "original_text": str(j.get("q", ""))[:300], "verdict": v, "satisfaction": sat, "note": str(j.get("note", ""))[:300], "client": j.get("client") or {}}); return {"ok": True}

    def abandon(self, j):
        """The person gave up on a task (a proposal was shown, nothing satisfactory could be run)."""
        self.log_interaction({"event": "abandoned", "participant": str(j.get("participant", ""))[:40], "task": str(j.get("task", ""))[:40], "original_text": str(j.get("q", ""))[:300], "reason": str(j.get("reason", ""))[:300], "client": j.get("client") or {}}); return {"ok": True}

    def feedback_export(self):
        out = []
        try:
            for fn in (paths.feedback_file() + ".1", paths.feedback_file()):
                if os.path.exists(fn):
                    for line in open(fn, encoding="utf-8"):
                        try: out.append(json.loads(line))
                        except ValueError: pass
        except OSError: pass
        return {"ok": True, "count": len(out), "items": out[-2000:]}

    def evidence(self, ts):
        from vgpt import qa_f
        try: A.set_tz(self.tz); return qa_f.chart(self.ro(), int(ts))
        except (ValueError, sqlite3.Error) as e: return {"ok": False, "why": "no signal data around that moment"}

    def thumb(self, ts):
        r = self.ro().execute("SELECT png FROM event_thumb WHERE ts=?", (int(ts),)).fetchone(); return r[0] if r else None


def make_handler(app):
    class H(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        def log_message(self, *x): pass

        def _send(self, body, ct="application/json", code=200):
            if not isinstance(body, bytes): body = json.dumps(body, default=str).encode()
            self.send_response(code); self.send_header("Content-Type", ct); self.send_header("Content-Length", str(len(body))); self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff"); self.send_header("Referrer-Policy", "no-referrer"); self.send_header("X-Frame-Options", "DENY")
            if ct.startswith("text/html"): self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'")
            self.end_headers(); self.wfile.write(body)

        def _same_site(self, post):
            """DNS-rebinding and cross-site request guard: the Host must be this server, a browser's Origin / Sec-Fetch-Site must say 'same origin', and a POST must be JSON (a web page cannot send that cross-site without a CORS pre-flight, which is never granted)."""
            bind_host = os.environ.get("VGPT_BIND", "127.0.0.1")
            ok_hosts = {f"127.0.0.1:{app.port}", f"localhost:{app.port}", f"[::1]:{app.port}", f"{bind_host}:{app.port}"}
            if self.headers.get("Host", "").lower() not in ok_hosts: return "bad host"
            o = self.headers.get("Origin")
            if o is not None and o.lower() not in {f"http://{h}" for h in ok_hosts}: return "bad origin"
            if self.headers.get("Sec-Fetch-Site", "same-origin") not in ("same-origin", "none"): return "cross-site"
            if post and not self.headers.get("Content-Type", "").lower().startswith("application/json"): return "unsupported content type"
            return None

        def _fail(self, why, code):
            LOG.warning("rejected request %s %s: %s", self.command, self.path.split("?")[0], why); self._send({"ok": False, "error": why}, code=code)

        def do_GET(self):
            u = urlparse(self.path)
            bad = self._same_site(False)
            if bad: return self._fail(bad, 403)
            try:
                if u.path == "/api/health": self._send(app.health())
                elif u.path == "/api/feedback/export": self._send(app.feedback_export())
                elif u.path == "/favicon.ico": self._send(b"", "image/x-icon", 204)
                elif u.path in ("/", "/app", "/app.html"): self._send(open(os.path.join(HERE, "app.html"), "rb").read(), "text/html; charset=utf-8")
                elif u.path in ("/headunit", "/index.html"): self._send(open(os.path.join(HERE, "index.html"), "rb").read(), "text/html; charset=utf-8")
                elif u.path == "/review": self._send(open(os.path.join(HERE, "review.html"), "rb").read(), "text/html; charset=utf-8")
                elif u.path in ("/research", "/research.html"): self._send(open(os.path.join(HERE, "research.html"), "rb").read(), "text/html; charset=utf-8")
                elif u.path == "/api/research/status": self._send(research_dashboard.snapshot())
                elif u.path == "/api/catalogue": self._send(app.brain.call("__catalogue__", {}))
                elif u.path == "/api/state": self._send(app.state())
                elif u.path == "/api/track": self._send(app.track(parse_qs(u.query).get("s", ["1800"])[0]))
                elif u.path == "/api/datasets": self._send({"datasets": app.datasets(), "current": app.dataset})
                elif u.path == "/api/evidence": self._send(app.evidence(parse_qs(u.query).get("ts", ["0"])[0]))
                elif u.path == "/api/thumb":
                    png = app.thumb(parse_qs(u.query).get("ts", ["0"])[0]); self._send(png, "image/png") if png else self._send(b"", "text/plain", 404)
                elif u.path == "/camera.mjpg": self.stream()
                else: self._send(b"not found", "text/plain", 404)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError): pass
            except Exception:                                               # same rule as POST: log it with an id, tell the user nothing about the internals
                eid = applog.error_id(); LOG.exception("unexpected error [%s] on %s", eid, u.path)
                try: self._send({"ok": False, "error": "Something went wrong inside the assistant.", "id": eid}, code=500)
                except Exception: pass

        def stream(self):
            self.send_response(200); self.send_header("Content-Type", "multipart/x-mixed-replace; boundary=frame"); self.send_header("Cache-Control", "no-store"); self.send_header("Connection", "close"); self.end_headers()
            seq = -1; rig = app.rig
            while True:
                with rig.cond:
                    rig.cond.wait_for(lambda: rig.seq != seq, 2.0); seq = rig.seq; jb = rig.jpeg
                if jb is None: continue
                self.wfile.write(b"--frame\r\nContent-Type: image/jpeg\r\nContent-Length: " + str(len(jb)).encode() + b"\r\n\r\n" + jb + b"\r\n")

        def do_POST(self):
            u = urlparse(self.path)
            bad = self._same_site(True)
            if bad: return self._fail(bad, 415 if "content type" in bad else 403)
            try:
                try: n = int(self.headers.get("Content-Length") or 0)
                except ValueError: return self._fail("bad length", 400)
                if n < 0 or n > MAX_BODY: return self._fail("request too large", 413)
                try: j = json.loads(self.rfile.read(n) or b"{}") if n else {}
                except ValueError: return self._fail("bad json", 400)
                if not isinstance(j, dict): return self._fail("bad json", 400)
                if u.path == "/api/feedback": return self._send(app.feedback(j))
                if u.path == "/api/interpret": return self._send(app.interpret(j))
                if u.path == "/api/execute": return self._send(app.execute(j))
                if u.path == "/api/judge": return self._send(app.judge(j))
                if u.path == "/api/abandon": return self._send(app.abandon(j))
                if u.path == "/api/ask":
                    q = str(j.get("q", ""))[:300].strip(); persona = "engineer" if j.get("persona") == "engineer" else "driver"
                    if not q: return self._send({"answer": "", "intent": "NONE", "path": "empty", "ms": {"total": 0}, "params": {}})
                    if app.brain.q.qsize() > 6: return self._send({"ok": False, "error": "The assistant is busy with earlier questions - try again in a moment."}, code=503)
                    r = app.brain.ask(q, persona); LOG.info("ask path=%s intent=%s ms=%s%s", r.get("path"), r.get("intent"), (r.get("ms") or {}).get("total"), (" q=" + q) if applog.log_questions() else "")
                    self._send(r)
                elif u.path == "/api/fault":
                    k = j.get("kind", "none"); app.rig.fault = k if k in FAULTS else "none"; self._send({"ok": True, "fault": app.rig.fault})
                elif u.path == "/api/camera":
                    s = j.get("source")
                    if s == "webcam": app.rig.want = ("webcam", int(j.get("index", 0)))
                    elif s == "file" and str(j.get("path", "")).lower().endswith(VIDEO_EXT) and os.path.isfile(str(j.get("path", ""))): app.rig.want = ("file", j["path"])
                    elif s == "clip": app.rig.want = ("clip", None)
                    else: return self._send({"ok": False, "error": "that is not a video file I can open" if s == "file" else "bad source"}, code=400)
                    app.rig.cmd = "reset"; self._send({"ok": True})
                elif u.path == "/api/playback":
                    sc = j.get("scenario"); sp = j.get("speed")
                    if sc in app.scen: app.clock.set(t=app.scen[sc][1], scenario=sc); app.rig.wipe_from = app.clock.now() - 1800; app.rig.cmd = "reset"
                    if sp in (1, 10, 60): app.clock.set(speed=float(sp))
                    self._send({"ok": True})
                elif u.path == "/api/units": self._send(app.brain.set_units({k: j[k] for k in ("p", "d", "t") if j.get(k) in ("kpa", "bar", "psi", "km", "mi", "c", "f")}))
                elif u.path == "/api/reset": app.rig.wipe_from = app.clock.now() - 1800; app.rig.cmd = "reset"; self._send({"ok": True})
                elif u.path == "/api/dataset":
                    names = [d["name"] for d in app.datasets()]
                    if j.get("name") not in names: return self._send({"ok": False, "error": "unknown dataset"}, code=400)
                    self._send(app.load(j["name"]))
                else: self._send(b"not found", "text/plain", 404)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError): pass
            except Exception as e:                                          # never show internals to the user; log them with an id the user can quote
                eid = applog.error_id(); LOG.exception("unexpected error [%s] on %s", eid, u.path)
                try: self._send({"ok": False, "error": "Something went wrong inside the assistant.", "id": eid}, code=500)
                except Exception: pass
    return H


def build_parser():
    ap = argparse.ArgumentParser(description="VehicleGPT head unit / assistant (local web app; Qwen2.5 0.5B is the only language model)"); ap.add_argument("--port", type=int, default=8765); ap.add_argument("--model", default="0.5b", choices=["0.5b", "none"])
    ap.add_argument("--db", default=("data/gen_demo.db" if os.path.exists(os.path.join(ROOT, "data", "gen_demo.db")) else "data/vehicle.db")); ap.add_argument("--camera", default="clip", choices=["clip", "webcam"]); ap.add_argument("--webcam-index", type=int, default=0)
    ap.add_argument("--live", default=None, help=argparse.SUPPRESS); ap.add_argument("--planner", default="fast", choices=["fast"], help=argparse.SUPPRESS); ap.add_argument("--threads", type=int, default=2)
    return ap


def make_server(a):
    """-> (server, app). Raises OSError('port in use') with a plain message."""
    applog.setup(); app = App(a)
    class Srv(ThreadingHTTPServer): daemon_threads = True; allow_reuse_address = False
    bind_host = os.environ.get("VGPT_BIND", "127.0.0.1")
    try: srv = Srv((bind_host, a.port), make_handler(app))
    except OSError as e:
        raise OSError(f"port {a.port} is already in use (is VehicleGPT already running? try --port {a.port + 1})") from e
    return srv, app


def main(argv=None):
    a = build_parser().parse_args(argv)
    try: srv, app = make_server(a)
    except OSError as e: print("VehicleGPT could not start:", e, file=sys.stderr); return 2
    LOG.info("VehicleGPT %s on http://127.0.0.1:%d (%s)", VERSION, a.port, a.planner)
    print(f"VehicleGPT {VERSION}: http://127.0.0.1:{a.port}   (Ctrl+C to stop)")
    try: srv.serve_forever()
    except KeyboardInterrupt: print("\nstopping...")
    finally: srv.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
